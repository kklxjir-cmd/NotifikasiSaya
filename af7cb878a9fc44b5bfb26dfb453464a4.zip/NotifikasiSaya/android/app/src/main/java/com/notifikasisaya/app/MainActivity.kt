package com.notifikasisaya.app

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject

class MainActivity : AppCompatActivity() {

    private val serverUrl = "http://IP_KAMU:2093/api/kirim-data"
    private lateinit var statusText: TextView
    private lateinit var serverInput: EditText
    private lateinit var simpanBtn: Button
    private lateinit var kirimBtn: Button

    private val requestPermissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { isGranted ->
            if (isGranted) {
                statusText.text = "✅ Izin notifikasi diberikan!"
                startNotificationService()
            } else {
                statusText.text = "⚠️ Izin notifikasi ditolak"
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        statusText = findViewById(R.id.statusText)
        serverInput = findViewById(R.id.serverUrl)
        simpanBtn = findViewById(R.id.simpanBtn)
        kirimBtn = findViewById(R.id.kirimBtn)

        // Muat URL server yang tersimpan
        val prefs = getSharedPreferences("AppPrefs", MODE_PRIVATE)
        serverInput.setText(prefs.getString("server_url", serverUrl))

        simpanBtn.setOnClickListener {
            val url = serverInput.text.toString().trim()
            prefs.edit().putString("server_url", url).apply()
            Toast.makeText(this, "URL Server Disimpan!", Toast.LENGTH_SHORT).show()
        }

        kirimBtn.setOnClickListener { kirimTestNotifikasi() }

        // Minta izin notifikasi SECARA TERBUKA & JELAS
        cekIzin()
    }

    private fun cekIzin() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            when {
                ContextCompat.checkSelfPermission(
                    this,
                    Manifest.permission.POST_NOTIFICATIONS
                ) == PackageManager.PERMISSION_GRANTED -> {
                    statusText.text = "✅ Izin sudah diberikan"
                    startNotificationService()
                }
                else -> {
                    statusText.text = "ℹ️ Meminta izin notifikasi..."
                    requestPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                }
            }
        } else {
            statusText.text = "✅ Tidak perlu izin khusus untuk versi ini"
        }
    }

    private fun startNotificationService() {
        val serviceIntent = Intent(this, MyNotificationService::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForegroundService(serviceIntent)
        } else {
            startService(serviceIntent)
        }
    }

    private fun kirimTestNotifikasi() {
        statusText.text = "📤 Mengirim notifikasi uji coba..."
        Thread {
            try {
                val url = getSharedPreferences("AppPrefs", MODE_PRIVATE)
                    .getString("server_url", serverUrl)!!

                val json = JSONObject().apply {
                    put("namaPerangkat", Build.MODEL)
                    put("tipe", "notifikasi")
                    put("info", "Ini notifikasi uji coba dari aplikasi kamu!\nWaktu: ${System.currentTimeMillis()}")
                }.toString()

                val body = json.toRequestBody("application/json".toMediaType())
                val request = Request.Builder()
                    .url(url)
                    .post(body)
                    .build()

                val client = OkHttpClient()
                val response = client.newCall(request).execute()
                
                runOnUiThread {
                    if (response.isSuccessful) {
                        statusText.text = "✅ Notifikasi terkirim ke Telegram!"
                    } else {
                        statusText.text = "❌ Gagal: Kode ${response.code}"
                    }
                }
            } catch (e: Exception) {
                runOnUiThread {
                    statusText.text = "❌ Error: ${e.message}"
                }
            }
        }.start()
    }
}
